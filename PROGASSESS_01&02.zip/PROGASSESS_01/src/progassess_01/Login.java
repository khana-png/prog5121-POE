/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progassess_01;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author RC_Student_lab
 */
class Login {

    
    public boolean validUsername(String username) {
        
    return username.contains("_")&& username.length() <= 5;
        
    }
    
    private String phoneNumber;
    
    public String getPhoneNumber() {
        return phoneNumber;
        
    }
    
    
    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }
    
    public boolean checkCellPhoneNumber(){
     String regex = "^(?:\\ +27||0)[6-8][0-9]{8}$";
      Pattern pattern = Pattern.compile(regex);
      
       Matcher match = pattern.matcher(phoneNumber);
        
       
        return match.matches(); 
    
    
    }
     public static String validatePassword(String password) {
        Pattern pattern = Pattern.compile("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return password;
        
        
     
    }
//public class LoginApp {

    // Sample user account stored (for simplicity)
    private static final String Username = null;
    private static final String Password = null;
    //private static final String firstName = "John";
    //private static final String lastName = "Doe";

    // Method to authenticate the user
    public static String authenticateUser(String username, String password) {
        if (username.equals(Username) && password.equals(Password)) {
            return "Welcome " + Username + " "+ Password +", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
       
   
        }
        
    }


    



     

    


