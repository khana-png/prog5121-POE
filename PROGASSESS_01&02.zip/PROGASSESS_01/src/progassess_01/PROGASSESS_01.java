/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progassess_01;

import java.util.*;
import java.util.Random;

/**
 *
 * @author RC_Student_lab
 */
public class PROGASSESS_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Login login = new Login();
        Scanner scanner = new Scanner(System.in);

        // Collect input from user
        System.out.println("Please enter your Name");
        String userName = scanner.nextLine();

        if (userName.contains("_") && userName.length() <= 5) {
            System.out.println("Name successfully captured.");
        } else {
            System.out.println("Name is not successfully captured.");

        }
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter your South African cell phone number:");
        login.setPhoneNumber(scan.nextLine());
        if (login.checkCellPhoneNumber()) {
            System.out.print("Phone number successfully stored\n");
        } else {
            System.out.println("Phone number unsuccessfully stored\n");
            login.setPhoneNumber(scan.nextLine());
        }

        System.out.println("Please enter your password ");
        String password = scanner.nextLine();
        boolean checkpassword = login.validUsername(password);
        if (checkpassword) {
            System.out.println("Password unsuccessfully stored");
        } else {
            System.out.println("Password successfully stored");
        }
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        password = scanner.nextLine();

        if (userName.equals(username) && password.equals(password)) {
            System.out.println("Welcome \n" + userName + "\n " + password + "\nIt is great to see you again.");
        } else {
            System.out.println("Username or password is incorrect, please enter correct details.");
        }

        System.out.println("Welcome to QuickChat");
        QuickChat quickChat = new QuickChat();
        login();

        int option;
        do {
            option = showMenu();
            handleOption(option);
        } while (option != 3);

        System.out.println("Exiting QuickChat. Goodbye!");
    }

    private static void login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: ");

        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (!username.isEmpty() && !password.isEmpty()) {
            boolean isLoggedIn = true;
            System.out.println("Login successful!");
        } else {
            System.out.println("Login failed! Please enter valid credentials.");
            login();
            System.out.println("Login successful!");
        }
    }

    private static int showMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nPlease choose an option:");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages (Coming Soon)");
        System.out.println("3) Quit");
        System.out.print("Enter option: ");
        return scanner.nextInt();

    }

    private static void handleOption(int option) {
        Scanner scanner = new Scanner(System.in);
        switch (option) {
            case 1:
                sendMessages();
                break;
            case 2:
                System.out.println("Coming Soon.");
                break;
            case 3:
                break;
            default:
                System.out.println("Invalid option! Please try again.");
        }
    }

    private static void sendMessages() {
        boolean isLoggedIn = true;
        if (!isLoggedIn) {
            System.out.println("You must log in first to send messages.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of messages to send: ");
        int numMessages = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numMessages; i++) {
            System.out.print("Enter recipient phone number (max 10 characters, include country code): ");
            String recipient = scanner.nextLine();

            System.out.print("Enter message content: ");
            String content = scanner.nextLine();
            //int messageCounter = 0;

            //messages.add(new Message(recipient, content, messageCounter++));
            System.out.println("""
                               Message is sent to
                               Recipient: """ + recipient + "\nConetent: " + content);
        }
    }
}


