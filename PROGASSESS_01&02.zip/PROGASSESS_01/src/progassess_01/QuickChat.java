/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progassess_01;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class QuickChat {

    class login {

        private static void login() {
            
        }

        private static int showMenu() {
            int showMenu = 0;

            return showMenu;
        }

    }
}
